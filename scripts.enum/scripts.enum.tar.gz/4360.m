inherits spiketrap;
