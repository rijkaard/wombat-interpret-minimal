inherits hairdye;
