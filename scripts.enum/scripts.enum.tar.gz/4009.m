inherits dye;
