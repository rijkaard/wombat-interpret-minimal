inherits sextant;
