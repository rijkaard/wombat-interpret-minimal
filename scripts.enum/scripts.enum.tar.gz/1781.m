inherits portcullis;
