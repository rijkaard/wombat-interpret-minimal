inherits ballofyarn;
