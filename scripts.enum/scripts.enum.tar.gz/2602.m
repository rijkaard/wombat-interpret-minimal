inherits furniture;
