inherits shuttleofthread;
