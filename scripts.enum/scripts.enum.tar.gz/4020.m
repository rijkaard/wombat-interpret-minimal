inherits blacksmith;
