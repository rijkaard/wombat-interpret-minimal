inherits gameboard;
