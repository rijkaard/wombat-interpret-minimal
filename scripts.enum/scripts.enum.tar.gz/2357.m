inherits fireplace;
