inherits cook;

trigger use {
	systemMessage(user, "What should I cook this on?");
	targetObj(user, this);
	return(0x01);
}

trigger targetobj {
	if (usedon == NULL()) {
		return(0x00);
	}
	list resources;
	if (getResourcesOnObj(usedon, 0x03, resources)) {
		if (isInList(resources, "fire")) {
			bark(this, "You cook the pie.");
			setType(this, 0x1041);
			attachScript(this, "4161");
			string name = getObjVar(this, "lookAtText");
			if (name == "unbaked apple pie") {
				name = "baked apple pie";
			}
			if (name == "unbaked peach cobbler") {
				name = "baked peach cobbler";
			}
			if (name == "unbaked quiche") {
				name = "baked quiche";
			}
			if (name == "unbaked fruit pie") {
				name = "baked fruit pie";
			}
			if (name == "unbaked meat pie") {
				name = "baked meat pie";
			}
			if (name == "unbaked pumpkin pie") {
				name = "baked pumpkin pie";
			}
			removeObjVar(this, "lookAtText");
			setObjVar(this, "lookAtText", name);
			detachScript(this, "4162");
		}
	}
	return(0x01);
}
