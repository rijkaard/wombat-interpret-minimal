inherits mining;
