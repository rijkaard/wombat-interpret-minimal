inherits scissors;
