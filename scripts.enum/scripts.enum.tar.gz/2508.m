inherits preparefish;
