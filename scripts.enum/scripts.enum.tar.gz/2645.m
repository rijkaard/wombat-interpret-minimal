inherits bedroll;
