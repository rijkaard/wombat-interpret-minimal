inherits dice;
