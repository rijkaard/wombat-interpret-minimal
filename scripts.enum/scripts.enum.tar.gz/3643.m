inherits spellbook;
