inherits clock;
